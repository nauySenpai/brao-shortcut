const { Client } = require('discord.js-selfbot-v13');
const fs = require('fs');

// Load configuration files
const config = JSON.parse(fs.readFileSync('./config.json', 'utf8'));
const shortcuts = JSON.parse(fs.readFileSync('./shortcut.json', 'utf8'));

// Create Discord client
const client = new Client();

// Store last message info to prevent infinite loops
let lastMessageInfo = {
    content: '',
    channelId: '',
    timestamp: 0
};

client.on('ready', () => {
    console.log(`✅ Selfbot đã sẵn sàng! Đăng nhập với tài khoản: ${client.user.tag}`);
    console.log(`📝 Đã tải ${Object.keys(shortcuts.shortcuts || {}).length} full shortcuts`);
    console.log(`📝 Đã tải ${Object.keys(shortcuts.partialShortcuts || {}).length} partial shortcuts`);
    console.log('🔥 Bot đang hoạt động...\n');

    // Display available shortcuts
    if (shortcuts.shortcuts && Object.keys(shortcuts.shortcuts).length > 0) {
        console.log('📋 Danh sách full shortcuts (thay thế toàn bộ tin nhắn):');
        Object.keys(shortcuts.shortcuts).forEach(key => {
            const shortcut = shortcuts.shortcuts[key];
            const message = typeof shortcut === 'string' ? shortcut : shortcut.message;
            const deleteFlag = typeof shortcut === 'string' ? '🗑️' : (shortcut.deleteOriginal ? '🗑️' : '📝');
            console.log(`   ${key} → ${message} ${deleteFlag}`);
        });
        console.log('');
    }

    if (shortcuts.partialShortcuts && Object.keys(shortcuts.partialShortcuts).length > 0) {
        console.log('📋 Danh sách partial shortcuts (thay thế một phần):');
        Object.keys(shortcuts.partialShortcuts).forEach(key => {
            const shortcut = shortcuts.partialShortcuts[key];
            const replacement = typeof shortcut === 'string' ? shortcut : shortcut.replacement;
            const deleteFlag = typeof shortcut === 'string' ? '🗑️' : (shortcut.deleteOriginal ? '🗑️' : '📝');
            console.log(`   ${key} → ${replacement} ${deleteFlag}`);
        });
        console.log('');
    }
});

client.on('messageCreate', async (message) => {
    // Only process messages from the selfbot user
    if (message.author.id !== client.user.id) return;

    // Prevent processing the same message multiple times
    const currentTime = Date.now();
    if (message.content === lastMessageInfo.content &&
        message.channel.id === lastMessageInfo.channelId &&
        currentTime - lastMessageInfo.timestamp < 2000) {
        return;
    }

    // Get message content
    let messageContent = message.content.trim();
    let originalContent = messageContent;

    // Check for partial shortcuts first (like .wsel → .waifu-select)
    // Only match if the shortcut is at the beginning of the message
    if (shortcuts.partialShortcuts) {
        let hasPartialMatch = false;
        let newContent = messageContent;
        let shouldDeleteOriginal = config.settings.deleteOriginalMessage; // Default from config

        Object.keys(shortcuts.partialShortcuts).forEach(shortKey => {
            const shortcut = shortcuts.partialShortcuts[shortKey];
            const replacement = typeof shortcut === 'string' ? shortcut : shortcut.replacement;

            // Check if message starts with the shortcut (case sensitive/insensitive)
            const messageToCheck = config.settings.caseSensitive ? messageContent : messageContent.toLowerCase();
            const keyToCheck = config.settings.caseSensitive ? shortKey : shortKey.toLowerCase();

            if (messageToCheck.startsWith(keyToCheck)) {
                // Make sure it's followed by space or end of string (not part of another word)
                const nextChar = messageContent.charAt(shortKey.length);
                if (nextChar === '' || nextChar === ' ') {
                    newContent = replacement + messageContent.substring(shortKey.length);
                    hasPartialMatch = true;

                    // Check if this specific shortcut has deleteOriginal setting
                    if (typeof shortcut === 'object' && shortcut.hasOwnProperty('deleteOriginal')) {
                        shouldDeleteOriginal = shortcut.deleteOriginal;
                    }

                    console.log(`🔄 Phát hiện partial shortcut ở đầu: "${shortKey}" → "${replacement}"`);
                }
            }
        });

        if (hasPartialMatch && newContent !== originalContent) {
            try {
                // Delete original message if enabled (use shortcut-specific setting or global setting)
                if (shouldDeleteOriginal) {
                    await message.delete();
                    console.log('🗑️ Đã xóa tin nhắn gốc');
                }

                // Add delay if specified
                if (config.settings.delay > 0) {
                    await new Promise(resolve => setTimeout(resolve, config.settings.delay));
                }

                // Send the modified message
                await message.channel.send(newContent);
                console.log(`✅ Đã gửi tin nhắn đã sửa: "${newContent}"`);

                // Update last message info to prevent loops
                lastMessageInfo = {
                    content: newContent,
                    channelId: message.channel.id,
                    timestamp: currentTime
                };

                return; // Exit early, don't check full shortcuts
            } catch (error) {
                console.error('❌ Lỗi khi xử lý partial shortcut:', error.message);
            }
        }
    }

    // Check for full shortcuts (exact match only)
    if (shortcuts.shortcuts) {
        if (!config.settings.caseSensitive) {
            messageContent = messageContent.toLowerCase();
        }

        const shortcutKeys = Object.keys(shortcuts.shortcuts);
        const matchedKey = shortcutKeys.find(key => {
            const keyToCheck = config.settings.caseSensitive ? key : key.toLowerCase();
            return messageContent === keyToCheck;
        });

        if (matchedKey) {
            try {
                const shortcut = shortcuts.shortcuts[matchedKey];
                const message_text = typeof shortcut === 'string' ? shortcut : shortcut.message;
                let shouldDeleteOriginal = config.settings.deleteOriginalMessage; // Default from config

                // Check if this specific shortcut has deleteOriginal setting
                if (typeof shortcut === 'object' && shortcut.hasOwnProperty('deleteOriginal')) {
                    shouldDeleteOriginal = shortcut.deleteOriginal;
                }

                console.log(`🔄 Phát hiện full shortcut: "${matchedKey}" → "${message_text}"`);

                // Delete original message if enabled (use shortcut-specific setting or global setting)
                if (shouldDeleteOriginal) {
                    await message.delete();
                    console.log('🗑️ Đã xóa tin nhắn gốc');
                }

                // Add delay if specified
                if (config.settings.delay > 0) {
                    await new Promise(resolve => setTimeout(resolve, config.settings.delay));
                }

                // Send the shortcut message
                await message.channel.send(message_text);
                console.log(`✅ Đã gửi tin nhắn: "${message_text}"`);

                // Update last message info to prevent loops
                lastMessageInfo = {
                    content: message_text,
                    channelId: message.channel.id,
                    timestamp: currentTime
                };

            } catch (error) {
                console.error('❌ Lỗi khi xử lý full shortcut:', error.message);
            }
        }
    }
});



client.on('error', (error) => {
    console.error('❌ Lỗi client:', error);
});

client.on('warn', (warning) => {
    console.warn('⚠️ Cảnh báo:', warning);
});

// Login to Discord
client.login(config.token).catch(error => {
    console.error('❌ Không thể đăng nhập:', error.message);
    console.log('💡 Hãy kiểm tra token trong file config.json');
});

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\n🛑 Đang tắt selfbot...');
    client.destroy();
    process.exit(0);
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
    console.error('❌ Unhandled Rejection at:', promise, 'reason:', reason);
});
